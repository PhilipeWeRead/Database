/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manchete;

import java.sql.SQLException;

import java.sql.*;
import DAO.ConectaBd;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Marce
 */
public class Manchete {
  
    
    public static void main(String[] args) throws SQLException, ClassNotFoundException, IOException
    {
        int choose;
        do
        {
            System.out.println("O que deseja fazer?");
            System.out.println("1 - Atualizar\n2 - Deletar\n3 - Consultar");
            Scanner sc = new Scanner (System.in);
            choose = Integer.parseInt(sc.next());
            switch(choose)
            {
                case 1:
                    Alterar altera = new Alterar();
                    altera.Conecta();
                    altera.AlterarDados();
                    break;
                case 2:
                    Deletar deleta = new Deletar();
                    deleta.Conecta();
                    deleta.DeletarDados();
                    break;
                case 3:
                    Buscar busca = new Buscar();
                    busca.Conecta();
                    busca.BuscarDados();
                    break;
            }
        }while(choose!=0);
        
        System.out.println("Programa encerrado com sucesso");
        
    }
    
}

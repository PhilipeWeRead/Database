/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manchete;

import DAO.ConectaBd;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author Marce
 */
public class Deletar {
    Connection con = null;
    Statement st = null;
    ResultSet rs = null;
    public void Conecta() throws ClassNotFoundException
    {
        con = ConectaBd.conectaBd();
    }     
      
     public void DeletarDados() throws SQLException, IOException
    {
        String table;
        String condition;
        System.out.println("O que deseja deletar?");
        System.out.println("Escolha a tabela: ");
        Scanner sc = new Scanner (System.in);
        table = sc.next();
        System.out.println("Escolha a condicao: ");
        sc = new Scanner (System.in);
        condition = sc.nextLine();
        
        String sql = "delete from "+table+ " where "+condition+";" ;
        
        try{
            st = con.createStatement();
            System.out.println(sql);
            int count = st.executeUpdate(sql);
            if(count>0)
            {
                System.out.println(table+ " deletada com sucesso");
               
            }
            
        }
        catch (SQLException error) {
            System.out.println("Dado não encontrado");
        }
    }
}

package manchete;

import DAO.ConectaBd;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.System.in;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.*;

/**
 *
 * @author Marce
 */
public class Alterar {
    Connection con = null;
    Statement st = null;
    ResultSet rs = null;
    public void Conecta() throws ClassNotFoundException
    {
        con = ConectaBd.conectaBd();
    }     
      
     public void AlterarDados() throws SQLException, IOException
    {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String column;
        String table;
        String valour;
        String key;
        String keyValour;
        System.out.println("O que deseja alterar?");
        System.out.println("Escolha a tabela: ");
        Scanner sc = new Scanner (System.in);
        table = sc.next();
        System.out.println("Escolha a coluna: ");
        sc = new Scanner (System.in);
        column = sc.next();
        sc.reset();
        System.out.println("Escolha o novo valor: ");
        //sc = new Scanner (System.in);
        valour = in.readLine();
        
        System.out.println("Escolha a chave: ");
        //sc = new Scanner (System.in);
        key = in.readLine();
        System.out.println("Escolha o valor da chave: ");
        sc = new Scanner (System.in);
        keyValour = sc.next();
        
        String sql = "update "+table+ " set "+column +" = " + valour + " where " + key+" = "+ keyValour+";" ;
        
        try{
            st = con.createStatement();
            System.out.println(sql);
            int count = st.executeUpdate(sql);
            if(count>0)
            {
                System.out.println(table+ " alterado com sucesso");
               
            }
            
        }
        catch (SQLException error) {
            System.out.println("Dado não encontrado");
        }
    }
}

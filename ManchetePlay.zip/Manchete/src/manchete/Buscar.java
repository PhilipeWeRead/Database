
package manchete;

import DAO.ConectaBd;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author Marce
 */
public class Buscar {
    Connection con = null;
    Statement st = null;
    ResultSet rs = null;
    public void Conecta() throws ClassNotFoundException
    {
        con = ConectaBd.conectaBd();
    }     
      
     public void BuscarDados() throws SQLException, IOException
    {
        System.out.println("O que gostaria de buscar?");
        System.out.println("1 - Atores com Filmes\n2 - Usuários por Estado\n3 - Tipo Pagamento");
        Scanner sc = new Scanner (System.in);
        String choose = sc.next();
        switch(choose)
        {
            case "1": BuscarAtoresComFilmes();
                break;
            case "2": BuscarUsuario();
                break;
            case "3": BuscarTipoPagamento();
                break;
        }
        
    }
    public void BuscarAtoresComFilmes()
    {
        String sql = "SELECT conteudo.titulo, conteudo.anoLancamento, ator.nomeArtistico, "
                    + "atua.nomePersonagem, ator.sexo " +
                    "FROM conteudo " +
                    "INNER JOIN filme ON filme.idConteudo = conteudo.id " +
                    "INNER JOIN atua ON atua.idConteudo = conteudo.id " +
                    "INNER JOIN ator ON atua.idAtor = ator.id " +
                    "ORDER BY ator.nomeArtistico;" ;
        
        try{
            st = con.createStatement();
            System.out.println(sql);
            //int count = st.executeUpdate(sql);
            rs = st.executeQuery(sql);
            while(rs.next())
            {
                String var = rs.getString("titulo");
                System.out.println("Título: "+var);
                var = rs.getString("anoLancamento");
                System.out.println("Ano de Lançamento: "+var);
                var = rs.getString("nomeArtistico");
                System.out.println("Nome Artístico: "+var);
                var = rs.getString("nomePersonagem");
                System.out.println("nomePersonagem: "+var);
                var = rs.getString("sexo");
                System.out.println("");
               
            }
        }
       
        catch (SQLException error) {
            System.out.println("Dado não encontrado");
        }
    }
    public void BuscarUsuario()
    {
        System.out.println("Digite o Estado Desejado: ");
        Scanner sc = new Scanner (System.in);
        String choose = sc.nextLine();
        String sql = "select * from usuario where estado = "+choose+";" ;
        
        try{
            st = con.createStatement();
            System.out.println(sql);
            //int count = st.executeUpdate(sql);
            rs = st.executeQuery(sql);
            while(rs.next())
            {
                String var = rs.getString("login");
                System.out.println("Login: "+var);
                var = rs.getString("primeiroNome");
                System.out.print("Nome: "+var);
                var = rs.getString("sobrenome");
                System.out.println(" "+var);
                var = rs.getString("cpf");
                System.out.println("CPF: "+var);
                var = rs.getString("telefone");
                System.out.println("Telefone: "+var);
                var = rs.getString("bairro");
                System.out.println("Bairro: "+var);
                var = rs.getString("logradouro");
                System.out.println("Logradouro: "+var);
                var = rs.getString("numero");
                System.out.println("Numero: "+var);
                var = rs.getString("cidade");
                System.out.println("Cidade: "+var);
                var = rs.getString("estado");
                System.out.println("Estado: "+var);
                var = rs.getString("pais");
                System.out.println("Pais: "+var);
                System.out.println("");
               
            }
        }
        
       
        catch (SQLException error) {
            System.out.println("Dado não encontrado");
        }
    }
    public void BuscarTipoPagamento()
    {
        
        String tipoPagamento;
        System.out.println("Insira o tipo de pagamento que deseja listar: ");
        System.out.println("CARTAO   |   BOLETO   |   VOUCHER ");
        Scanner sc = new Scanner (System.in);
        tipoPagamento = sc.next();
        String column="";
        if(tipoPagamento.equalsIgnoreCase("voucher"))
        {
            column = "periododeuso";
        }
        else if(tipoPagamento.equalsIgnoreCase("cartao"))
        {
            column = "tipo";
        }
        else if(tipoPagamento.equalsIgnoreCase("boleto"))
        {
            column = "codigoBarras";
        }
                
        String sql="Select usuario.primeiroNome, usuario.sobrenome, pagamento.valor, "+
                tipoPagamento+"."+column +
                " FROM pagamento INNER JOIN " +tipoPagamento+ " ON pagamento.numeroFatura = "
                + tipoPagamento+ ".numeroFaturaPagamento "
                + "INNER JOIN Usuario on pagamento.loginUsuario = " + "usuario.login "
                + "ORDER BY usuario.login";
        try{
            
            st = con.createStatement();
            System.out.println(sql);
            //int count = st.executeUpdate(sql);
            rs = st.executeQuery(sql);
            while(rs.next())
            {
                String var = rs.getString("primeiroNome");
                System.out.print("NOME: "+var);
                var = rs.getString("sobrenome");
                System.out.println(" "+var);
                var = rs.getString("valor");
                System.out.println("VALOR: R$"+var);
                var = rs.getString(column);
                System.out.println(column+": "+var);
                System.out.println("");
                
               
            }
        }
       
        catch (SQLException error) {
            System.out.println("Dado não encontrado");
        }
        
    }
}
